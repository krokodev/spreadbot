 function getFileListToLoad() {
	return "availability.js";
 }
 
