/*
 * This function should return the list of java script files to be loaded before processing the feed.
 * The files will be loaded in the listed order.
 */
 function getFileListToLoad() {
	return "location.js";
 }
 
